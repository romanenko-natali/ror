# app/controllers/meme_templates_controller.rb
class MemeTemplatesController < ApplicationController
  def index
    @meme_templates = MemeTemplate.all
  end

  def show
    @meme_template = MemeTemplate.find(params[:id])
  end
end
