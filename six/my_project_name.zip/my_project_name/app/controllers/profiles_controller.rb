class MemesController < ApplicationController
  def new
    @meme = Meme.new
  end
  
  def create
    @meme = Meme.new(meme_params)
    if @meme.save
      redirect_to @meme, notice: 'Meme was successfully uploaded.'
    else
      render :new
    end
  end
  
  def show
    @meme = Meme.find(params[:id])
  end
  
  private
  
  def meme_params
    params.require(:meme).permit(:title, :image)
  end
end
