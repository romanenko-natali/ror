# app/controllers/memes_controller.rb
class MemesController < ApplicationController
  before_action :authenticate_user!

  def create
    @meme = current_user.memes.build(meme_params)
    if @meme.save
      redirect_to profile_path, notice: "Meme created successfully"
    else
      # Handle validation errors
    end
  end

  def random
    @memes = Meme.order("RANDOM()").limit(10) # Вибираємо випадкові меми
    render json: @memes
  end
  
  private

  def meme_params
    params.require(:meme).permit(:title, :description, :image)
  end
end
