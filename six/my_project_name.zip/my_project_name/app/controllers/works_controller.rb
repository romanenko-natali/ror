# app/controllers/works_controller.rb
class WorksController < ApplicationController
  before_action :authenticate_user!

  def create
    @work = current_user.works.build(work_params)
    if @work.save
      redirect_to profile_path, notice: "Work uploaded successfully"
    else
      # Handle validation errors
    end
  end

  private

  def work_params
    params.require(:work).permit(:title, :description, :file)
  end
end
