class MemeTemplate < ApplicationRecord
end
