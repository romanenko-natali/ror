# app/models/user.rb

class User < ActiveRecord::Base
    validates :name, presence: true, length: { maximum: 50 }
    validates :email, presence: true, length: { maximum: 255 }, format: { with: URI::MailTo::EMAIL_REGEXP }

  # Перевірка мінімальної довжини пароля
  validates :password, length: { minimum: 6 }

  # Підтвердження паролю
  validates :password, confirmation: true

  # Перевірка формату електронної адреси
  validates :email, format: { with: URI::MailTo::EMAIL_REGEXP }
  has_many :works
  has_many :memes
end
