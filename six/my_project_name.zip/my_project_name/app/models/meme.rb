class Meme < ApplicationRecord
  belongs_to :user
end
