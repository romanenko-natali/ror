# app/models/work.rb
class Work < ApplicationRecord
  belongs_to :user
  # Add validations for work attributes here
end
