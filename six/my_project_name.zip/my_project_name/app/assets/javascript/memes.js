// app/assets/javascripts/memes.js

document.addEventListener("DOMContentLoaded", function() {
    setInterval(refreshMemes, 600000); // Оновлення кожні 10 хвилин
  });
  
  function refreshMemes() {
    fetch('/memes/random')
      .then(response => response.json())
      .then(data => {
        // Оновлення вмісту сторінки з отриманими мемами
        updateMemes(data);
      });
  }
  
  function updateMemes(memes) {
    const memesContainer = document.getElementById('memes-container');
    memesContainer.innerHTML = ''; // Очистка вмісту перед оновленням
  
    memes.forEach(meme => {
      const memeElement = document.createElement('div');
      memeElement.innerHTML = `<img src="${meme.image_url}" alt="${meme.title}">`;
      memesContainer.appendChild(memeElement);
    });
  }
  