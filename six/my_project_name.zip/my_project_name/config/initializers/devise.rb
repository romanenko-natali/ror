# config/initializers/devise.rb
Devise.setup do |config|
    config.authentication_keys = [:email]
  end
  