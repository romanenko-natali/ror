Rails.application.routes.draw do
  get 'meme_templates/index'
  get 'meme_templates/show'
  get 'memes/create'
  get 'works/create'
  get 'profiles/show'
  get 'profiles/edit'
  get 'profiles/update'
  resources :users, only: [:new, :create]

  # Інші маршрути
  resources :meme_templates, only: [:index, :show]
  devise_for :users

  # Логін, вихід, і т.д.
  get    '/login',  to: 'sessions#new'
  post   '/login',  to: 'sessions#create'
  delete '/logout', to: 'sessions#destroy'
end
