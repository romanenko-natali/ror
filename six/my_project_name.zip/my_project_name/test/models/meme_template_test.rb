require "test_helper"

class MemeTemplateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
